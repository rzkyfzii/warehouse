// src/data/barcodeMap.js

const barcodeMap = {
  // BALINESE
  "8994457783468": { variant: "LOVE OUD", category: "Parfum - Balinese" },
  "8994457783505": { variant: "ROSE", category: "Parfum - Balinese" },
  "8994457783567": { variant: "OCEAN D PARADIS", category: "Parfum - Balinese" },
  "8994457783529": { variant: "SUNSET FALVOR", category: "Parfum - Balinese" },
  "8994457783550": { variant: "LOVE FRANGIPANI", category: "Parfum - Balinese" },
  "8994457783475": { variant: "OMBRE", category: "Parfum - Balinese" },
  "8994457783574": { variant: "CIGAR NOIR", category: "Parfum - Balinese" },
  "8994457783536": { variant: "SENSO D BLOSSOM", category: "Parfum - Balinese" },
  "8994457783451": { variant: "BROTHERHOOD STORY", category: "Parfum - Balinese" },
  "8994457783482": { variant: "SONG OF JOY", category: "Parfum - Balinese" },
  "8994457783499": { variant: "AMBER VOUGERE", category: "Parfum - Balinese" },
  "8994457783512": { variant: "AMETHYST", category: "Parfum - Balinese" },
  "8994457783543": { variant: "GOLD FRANGIPANI", category: "Parfum - Balinese" },

  // EKSKLUSIF
  "8997019514722": { variant: "GLORIOUS MOONLIGHT", category: "Parfum - Eksklusif" },
  "8997019516160": { variant: "L AME DE L OCEAN", category: "Parfum - Eksklusif" },
  "8997019514715": { variant: "SENSO DI BLOSSOM", category: "Parfum - Eksklusif" },
  "8997019514999": { variant: "SUNSET FALVOR", category: "Parfum - Eksklusif" },

  // CLASSIC (Exrait)
  "8997019514777": { variant: "AMBER VOUGERE", category: "Parfum - Classic" },
  "8997019513008": { variant: "AMETHYST", category: "Parfum - Classic" },
  "89970195130460": { variant: "BROTHERHOOD STORY", category: "Parfum - Classic" },
  "2004": { variant: "HAPPINESS", category: "Parfum - Classic" },
  "8997019512650": { variant: "OMBRE", category: "Parfum - Classic" },
  "8997019512704": { variant: "ROSES", category: "Parfum - Classic" },
  "8997019513053": { variant: "JASMINUM SAMBAC", category: "Parfum - Classic" },
  "8997019514784": { variant: "LOVE OUD", category: "Parfum - Classic" },
  "8997019514876": { variant: "MAGIC OF NATURE", category: "Parfum - Classic" },
  "8997019513091": { variant: "MATCHER", category: "Parfum - Classic" },

  // SANJU
  "3001": { variant: "MEN PERFUME (RED)", category: "Parfum - Sanju" },
  "3002": { variant: "MEN PERFUME (WHITE)", category: "Parfum - Sanju" },
  "3003": { variant: "MEN PERFUME (YELLOW)", category: "Parfum - Sanju" },
  "3004": { variant: "SENCE AMETHYST", category: "Parfum - Sanju" },
  "3005": { variant: "SENCE HAPPY", category: "Parfum - Sanju" },
  "3006": { variant: "SENCE JOYFUL", category: "Parfum - Sanju" },
  "3007": { variant: "SENCE LOVELY", category: "Parfum - Sanju" },
  "3008": { variant: "SENCE ROMANCE", category: "Parfum - Sanju" },
  "3009": { variant: "SENCE SECRET", category: "Parfum - Sanju" },

  // BODY SPRAY (Aerosols)
  "8997019518393": { variant: "MEN BODY SPRAY (RED)", category: "Body Spray - Aerosols" },
  "8997019518379": { variant: "MEN BODY SPRAY (WHITE)", category: "Body Spray - Aerosols" },
  "8997019518386": { variant: "MEN BODY SPRAY (YELLOW)", category: "Body Spray - Aerosols" },
  "6956760212433": { variant: "SENCE BODY SPRAY HAPPY", category: "Body Spray - Aerosols" },
  "6956760212430": { variant: "SENCE BODY SPRAY JOYFUL", category: "Body Spray - Aerosols" },
  "6956760212431": { variant: "SENCE BODY SPRAY LOVELY", category: "Body Spray - Aerosols" },
  "6956760212432": { variant: "SENCE BODY SPRAY ROMANCE", category: "Body Spray - Aerosols" },

  // DIFFUSER
  "5001": { variant: "DISFFUSER FLORAL SENSATION", category: "Home Care - Diffuser" },
  "5002": { variant: "DISFFUSER WARM TOBACCO", category: "Home Care - Diffuser" },
  "5003": { variant: "DISFFUSER WOODY", category: "Home Care - Diffuser" },
  "5004": { variant: "DISFFUSER WHITE", category: "Home Care - Diffuser" },
  "5005": { variant: "DISFFUSER BLUE", category: "Home Care - Diffuser" },
  "5006": { variant: "DISFFUSER", category: "Home Care - Diffuser" },

  // HAIR CARE
  "6001": { variant: "HAIR CREAM (BLACK)", category: "Hair Care" },
  "6002": { variant: "HAIR CREAM (WHITE)", category: "Hair Care" },
  "6003": { variant: "SUPER HARD GEL (PURPLE)", category: "Hair Care" },
  "8997019519048": { variant: "SUPER HARD GEL (GREEN FIX)", category: "Hair Care" },
  "8997019519055": { variant: "SUPER HARD GEL (BLUE)", category: "Hair Care" }
};

export const getBarcodeInfo = (barcode) => {
  return barcodeMap[barcode] || null;
};
