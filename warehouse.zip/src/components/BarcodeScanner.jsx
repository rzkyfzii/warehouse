import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { X, Camera, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { getBarcodeInfo } from '@/data/barcodeMap';

const BarcodeScanner = ({ onDetected, onClose }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState(null);
  const [stream, setStream] = useState(null);
  const [hasPermission, setHasPermission] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
  const delayStart = setTimeout(() => {
    checkCameraPermission();
  }, 500); // kasih delay agar video ref sempat render

  return () => {
    clearTimeout(delayStart);
    stopCamera();
  };
}, []);


  const checkCameraPermission = async () => {
    try {
      const permission = await navigator.permissions.query({ name: 'camera' });
      setHasPermission(permission.state === 'granted');
      
      if (permission.state === 'granted') {
        startCamera();
      } else if (permission.state === 'prompt') {
        startCamera();
      } else {
        setError('Akses kamera ditolak. Mohon berikan izin kamera untuk menggunakan scanner.');
      }
    } catch (err) {
      startCamera();
    }
  };

const startCamera = async () => {
  try {
    setError(null);

    const constraints = {
      video: {
        facingMode: 'environment',
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
    };

    const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
    console.log("✅ stream:", mediaStream); // <-- Tambah log ini
    setStream(mediaStream);
    setHasPermission(true);

    if (videoRef.current) {
      console.log("✅ videoRef.current:", videoRef.current); // <-- Tambah log ini
      videoRef.current.srcObject = mediaStream;

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.play()
            .then(() => {
              console.log("✅ Kamera berhasil diputar"); // <-- Tambah log ini
              setIsScanning(true);
              startScanningSimulation();
            })
            .catch(err => {
              console.error("❌ Gagal play:", err); // <-- Tambah log ini
              setError('Kamera tersedia, tapi gagal diputar. Pastikan tidak digunakan aplikasi lain.');
            });
        }
      }, 300);
    }
  } catch (err) {
    console.error('❌ Gagal akses kamera:', err); // <-- Tambah log ini
    setHasPermission(false);

    if (err.name === 'NotAllowedError') {
      setError('Akses kamera ditolak. Cek izin browser.');
    } else if (err.name === 'NotFoundError') {
      setError('Kamera tidak ditemukan.');
    } else {
      setError('Gagal mengakses kamera.');
    }
  }
};


  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => {
        track.stop();
      });
      setStream(null);
    }
    setIsScanning(false);
  };

  const startScanningSimulation = () => {
    setTimeout(() => {
      if (isScanning) {
        simulateBarcodeScan();
      }
    }, 3000);
  };

  const simulateBarcodeScan = () => {
    const sampleBarcodes = [
      '1234567890123',
      '2345678901234', 
      '3456789012345',
      '4567890123456',
      '5678901234567',
      '6789012345678',
      '7890123456789',
      '8901234567890'
    ];
    
    const randomBarcode = sampleBarcodes[Math.floor(Math.random() * sampleBarcodes.length)];
    const barcodeInfo = getBarcodeInfo(randomBarcode);
    
    if (barcodeInfo) {
      toast({
        title: "Barcode Terdeteksi! 🎯",
        description: `${barcodeInfo.variant} - ${barcodeInfo.category}`,
      });
    } else {
      toast({
        title: "Barcode Terdeteksi! 🎯",
        description: `Kode: ${randomBarcode}`,
      });
    }
    
    onDetected(randomBarcode);
  };

  const handleManualInput = () => {
    const barcode = prompt('Masukkan barcode secara manual:');
    if (barcode && barcode.trim()) {
      const barcodeInfo = getBarcodeInfo(barcode.trim());
      
      if (barcodeInfo) {
        toast({
          title: "Barcode Ditemukan! 📦",
          description: `${barcodeInfo.variant} - ${barcodeInfo.category}`,
        });
      }
      
      onDetected(barcode.trim());
    }
  };

  const requestCameraPermission = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setHasPermission(true);
      startCamera();
    } catch (err) {
      setHasPermission(false);
      setError('Gagal mendapatkan izin kamera. Mohon berikan izin secara manual di pengaturan browser.');
    }
  };

  return (
    <DialogContent className="max-w-2xl bg-gradient-to-br from-slate-900 to-purple-900 border-purple-500">
      <DialogHeader>
        <DialogTitle className="text-white flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Scanner Barcode
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        {error ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-8"
          >
            <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <p className="text-red-300 mb-4">{error}</p>
            
            <div className="space-y-2">
              {hasPermission === false && (
                <Button
                  onClick={requestCameraPermission}
                  className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 mr-2"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Izinkan Kamera
                </Button>
              )}
              
              <Button
                onClick={handleManualInput}
                className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
              >
                Input Manual
              </Button>
            </div>
          </motion.div>
        ) : (
          <div className="relative">
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
                muted
              />
              
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="border-2 border-emerald-400 rounded-lg"
                  style={{ width: '60%', height: '40%' }}
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(16, 185, 129, 0.7)',
                      '0 0 0 10px rgba(16, 185, 129, 0)',
                      '0 0 0 0 rgba(16, 185, 129, 0)'
                    ]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-emerald-400"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-emerald-400"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-emerald-400"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-emerald-400"></div>
                </motion.div>
              </div>

              {isScanning && (
                <motion.div
                  className="absolute left-1/2 transform -translate-x-1/2 w-3/5 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent"
                  animate={{
                    y: [0, 200, 0]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              )}

              {!isScanning && hasPermission && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  <div className="text-center">
                    <div className="spinner mb-4"></div>
                    <p className="text-white">Memulai kamera...</p>
                  </div>
                </div>
              )}
            </div>

            <canvas ref={canvasRef} className="hidden" />
          </div>
        )}

        <div className="text-center space-y-2">
          <p className="text-purple-200">
            Arahkan kamera ke barcode untuk memindai
          </p>
          {isScanning && (
            <motion.div
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="text-emerald-400 font-medium flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              Sedang memindai...
            </motion.div>
          )}
        </div>

        <div className="flex gap-2 justify-center">
          <Button
            onClick={handleManualInput}
            variant="outline"
            className="border-purple-300 text-purple-100 hover:bg-purple-800"
          >
            Input Manual
          </Button>
          
          <Button
            onClick={simulateBarcodeScan}
            className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
          >
            Demo Scan
          </Button>
          
          <Button
            onClick={onClose}
            variant="outline"
            className="border-red-300 text-red-100 hover:bg-red-800"
          >
            <X className="w-4 h-4 mr-2" />
            Tutup
          </Button>
        </div>
      </div>
    </DialogContent>
  );
};

export default BarcodeScanner;
